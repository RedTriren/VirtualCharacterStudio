
import json
import threading
import time

from websockets.sync.server import serve


class PoseWebSocketServer:
    def __init__(self, host="127.0.0.1", port=8765):
        self.host = host
        self.port = port
        self.latest_message = None
        self.lock = threading.Lock()

    def publish(self, landmarks):
        message = {
            "type": "pose",
            "timestamp": time.time(),
            "landmarks": [
                {
                    "id": i,
                    "x": float(p.x),
                    "y": float(p.y),
                    "z": float(p.z),
                    "visibility": float(p.visibility)
                }
                for i, p in enumerate(landmarks)
            ]
        }

        with self.lock:
            self.latest_message = json.dumps(message)

    def handle_client(self, websocket):
        print("Unity 클라이언트 연결됨")

        try:
            last_message = None

            while True:
                with self.lock:
                    message = self.latest_message

                if message is not None and message != last_message:
                    websocket.send(message)
                    last_message = message

                time.sleep(1 / 60)

        except Exception as e:
            print("클라이언트 연결 종료:", e)

    def start(self):
        def run():
            with serve(
                self.handle_client,
                self.host,
                self.port
            ) as server:
                print(
                    f"WebSocket 서버 시작: "
                    f"ws://{self.host}:{self.port}"
                )
                server.serve_forever()

        thread = threading.Thread(
            target=run,
            daemon=True
        )
        thread.start()
