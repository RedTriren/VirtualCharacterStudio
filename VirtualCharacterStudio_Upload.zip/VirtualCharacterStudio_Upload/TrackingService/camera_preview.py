
import cv2
import time

cap = cv2.VideoCapture(0, cv2.CAP_DSHOW)

if not cap.isOpened():
    raise RuntimeError("웹캠 연결 실패")

print("Resolution:",
      cap.get(cv2.CAP_PROP_FRAME_WIDTH),
      cap.get(cv2.CAP_PROP_FRAME_HEIGHT))

prev_time = time.perf_counter()
fps = 0.0

while True:
    success, frame = cap.read()

    if not success or frame is None:
        print("프레임 획득 실패")
        break

    now = time.perf_counter()
    dt = now - prev_time
    prev_time = now

    if dt > 0:
        fps = 1.0 / dt

    frame = cv2.flip(frame, 1)

    cv2.putText(
        frame,
        f"FPS: {fps:.1f}",
        (20, 40),
        cv2.FONT_HERSHEY_SIMPLEX,
        1,
        (0, 255, 0),
        2
    )

    cv2.imshow("Camera Preview", frame)

    if cv2.waitKey(1) & 0xFF == 27:
        break

cap.release()
cv2.destroyAllWindows()
