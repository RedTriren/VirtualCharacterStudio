import time
import cv2
import mediapipe as mp

from mediapipe.tasks import python
from mediapipe.tasks.python import vision

from pathlib import Path
from websocket_server import PoseWebSocketServer

BASE_DIR = Path(__file__).resolve().parent
MODEL_PATH = BASE_DIR / "pose_landmarker_lite.task"

print("모델 경로:", MODEL_PATH)
print("모델 파일 존재:", MODEL_PATH.exists())


# 모델 파일
MODEL_PATH = "pose_landmarker_lite.task"

# MediaPipe 초기화
BaseOptions = python.BaseOptions
PoseLandmarker = vision.PoseLandmarker
PoseLandmarkerOptions = vision.PoseLandmarkerOptions
RunningMode = vision.RunningMode

options = PoseLandmarkerOptions(
    base_options=BaseOptions(
        model_asset_path=MODEL_PATH
    ),
    running_mode=RunningMode.VIDEO,
    num_poses=1,
    min_pose_detection_confidence=0.5,
    min_pose_presence_confidence=0.5,
    min_tracking_confidence=0.5,
)

# 웹캠 실행
cap = cv2.VideoCapture(0, cv2.CAP_DSHOW)

if not cap.isOpened():
    raise RuntimeError("웹캠을 열 수 없습니다.")

print("연결 성공")
print("Width:", cap.get(cv2.CAP_PROP_FRAME_WIDTH))
print("Height:", cap.get(cv2.CAP_PROP_FRAME_HEIGHT))
print("Camera FPS:", cap.get(cv2.CAP_PROP_FPS))

frame_index = 0
start_time = time.perf_counter()

fps = 0.0
fps_frame_count = 0
fps_start_time = start_time

pose_server = PoseWebSocketServer()
pose_server.start()

# 아래는 호출 전후의 딜레이 확인

inference_ms = (
    time.perf_counter() - start_time
) * 1000


with PoseLandmarker.create_from_options(options) as landmarker:

    while True:
        success, frame = cap.read()

        if not success or frame is None:
            print("웹캠 프레임을 읽을 수 없습니다.")
            break

        # 좌우 반전: 거울처럼 보이게 표시
        frame = cv2.flip(frame, 1)

        # OpenCV BGR -> MediaPipe RGB
        rgb_frame = cv2.cvtColor(
            frame,
            cv2.COLOR_BGR2RGB
        )

        mp_image = mp.Image(
            image_format=mp.ImageFormat.SRGB,
            data=rgb_frame
        )

        # VIDEO 모드에는 프레임별 타임스탬프가 필요함
        timestamp_ms = int(
            (time.perf_counter() - start_time) * 1000
        )

        # 이전 프레임보다 타임스탬프가 커지도록 보장
        timestamp_ms = max(timestamp_ms, frame_index)

        result = landmarker.detect_for_video(
            mp_image,
            timestamp_ms
        )
        if result.pose_world_landmarks:
            world_landmarks = result.pose_world_landmarks[0]
            pose_server.publish(world_landmarks)

        frame_index += 1

        # 추정 결과 표시
        if result.pose_landmarks:

            landmarks = result.pose_landmarks[0]

            # 이미지 좌표계의 랜드마크 표시
            for index, landmark in enumerate(landmarks):

                x = int(landmark.x * frame.shape[1])
                y = int(landmark.y * frame.shape[0])

                if 0 <= x < frame.shape[1] and \
                   0 <= y < frame.shape[0]:

                    cv2.circle(
                        frame,
                        (x, y),
                        4,
                        (0, 255, 0),
                        -1
                    )

            # 3D 월드 좌표 확인
            if result.pose_world_landmarks:

                world_landmarks = (
                    result.pose_world_landmarks[0]
                )

                cv2.putText(
                    frame,
                    f"World landmarks: {len(world_landmarks)}",
                    (20, 70),
                    cv2.FONT_HERSHEY_SIMPLEX,
                    0.7,
                    (0, 255, 0),
                    2
                )

                # 첫 프레임에서 랜드마크 데이터 출력
                if frame_index == 1:
                    print("World landmark count:",
                          len(world_landmarks))

                    for i, landmark in enumerate(
                        world_landmarks
                    ):
                        print(
                            i,
                            round(landmark.x, 4),
                            round(landmark.y, 4),
                            round(landmark.z, 4)
                        )

        else:
            cv2.putText(
                frame,
                "No pose detected",
                (20, 40),
                cv2.FONT_HERSHEY_SIMPLEX,
                0.8,
                (0, 0, 255),
                2
            )

        # FPS 계산
        now = time.perf_counter()
        fps_frame_count += 1

        elapsed = now - fps_start_time

        if elapsed >= 1.0:
            fps = fps_frame_count / elapsed

            fps_frame_count = 0
            fps_start_time = now



        cv2.putText(
            frame,
            f"FPS: {fps:.1f}",
            (20, 35),
            cv2.FONT_HERSHEY_SIMPLEX,
            0.7,
            (255, 255, 0),
            2
        )

        cv2.imshow(
            "Virtual Character Studio - BlazePose",
            frame
        )

        # ESC 키로 종료
        if cv2.waitKey(1) & 0xFF == 27:
            break

cap.release()
cv2.destroyAllWindows()