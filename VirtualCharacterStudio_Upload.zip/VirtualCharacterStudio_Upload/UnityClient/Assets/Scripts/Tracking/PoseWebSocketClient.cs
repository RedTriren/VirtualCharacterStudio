
using System;
using System.Text;
using UnityEngine;
using NativeWebSocket;

public class PoseWebSocketClient : MonoBehaviour
{
    public string serverUrl = "ws://127.0.0.1:8765";

    public PoseSkeletonVisualizer visualizer;
    public PoseTrackingProcessor trackingProcessor;
    public FullBodyRetargeter fullBodyRetargeter;

    private WebSocket websocket;

    private async void Start()
    {
        websocket = new WebSocket(serverUrl);

        websocket.OnOpen += () =>
        {
            Debug.Log("Python WebSocket 연결 성공");
        };

        websocket.OnError += error =>
        {
            Debug.LogError("WebSocket 오류: " + error);
        };

        websocket.OnClose += code =>
        {
            Debug.Log("WebSocket 연결 종료: " + code);
        };

        websocket.OnMessage += bytes =>
        {
            string json = Encoding.UTF8.GetString(bytes);

            PoseMessage message =
                JsonUtility.FromJson<PoseMessage>(json);

            if (message != null &&
                message.landmarks != null &&
                message.landmarks.Length == 33)
            {
                if (visualizer != null)
                {
                    visualizer.UpdatePose(message.landmarks);
                }
                    // 공통 데이터 처리
                PoseLandmark[] processed =
                    trackingProcessor != null
                        ? trackingProcessor.Process(message.landmarks)
                        : message.landmarks;

                // 전신 리타게팅 컨트롤러로 전달
                if (fullBodyRetargeter != null)
                {
                    fullBodyRetargeter.SetPose(processed);
                }
            }
        };

        try
        {
            await websocket.Connect();
        }
        catch (Exception e)
        {
            Debug.LogError("연결 실패: " + e.Message);
        }
    }

    private void Update()
    {
#if !UNITY_WEBGL || UNITY_EDITOR
        websocket?.DispatchMessageQueue();
#endif
    }

    private async void OnDestroy()
    {
        if (websocket != null)
        {
            await websocket.Close();
        }
    }
}
