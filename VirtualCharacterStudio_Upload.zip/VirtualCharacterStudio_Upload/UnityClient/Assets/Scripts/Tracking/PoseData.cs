
using System;
using UnityEngine;

[Serializable]
public class PoseLandmark
{
    public int id;
    public float x;
    public float y;
    public float z;
    public float visibility;
}

[Serializable]
public class PoseMessage
{
    public string type;
    public double timestamp;
    public PoseLandmark[] landmarks;
}
