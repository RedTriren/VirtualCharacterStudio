
using UnityEngine;

public class UpperBodyRetargeter : MonoBehaviour
{
    [Header("Avatar")]
    public Animator animator;

    [Header("Coordinate Mapping")]
    public bool invertX = false;
    public bool invertY = true;
    public bool invertZ = true;

    [Header("Tracking")]
    [Range(0f, 1f)]
    public float minVisibility = 0.5f;

    [Header("Rotation")]
    [Range(0f, 1f)]
    public float rotationWeight = 0.7f;

    public bool enableRotation = true;

    private Transform chest;
    private Quaternion chestRestLocal;

    private Quaternion referencePoseRotation;
    private Quaternion currentPoseRotation;

    private bool initialized;
    private bool hasPose;
    private bool calibrated;

    private void Start()
    {
        if (animator == null)
            animator = GetComponentInChildren<Animator>();

        if (animator == null ||
            animator.avatar == null ||
            !animator.avatar.isValid ||
            !animator.avatar.isHuman)
        {
            Debug.LogError("Humanoid Avatar 설정 오류");
            return;
        }

        chest = animator.GetBoneTransform(
            HumanBodyBones.Chest);

        if (chest == null)
        {
            chest = animator.GetBoneTransform(
                HumanBodyBones.Spine);
        }

        if (chest == null)
        {
            Debug.LogError("Chest/Spine 뼈를 찾지 못했습니다.");
            return;
        }

        chestRestLocal = chest.localRotation;
        initialized = true;

        Debug.Log("상체 리타게팅 준비 완료");
    }

    private Vector3 Convert(PoseLandmark p)
    {
        return new Vector3(
            invertX ? -p.x : p.x,
            invertY ? -p.y : p.y,
            invertZ ? -p.z : p.z
        );
    }

    public void SetPose(PoseLandmark[] landmarks)
    {
        if (!initialized ||
            landmarks == null ||
            landmarks.Length != 33)
        {
            hasPose = false;
            return;
        }

        int[] ids = { 11, 12, 23, 24 };

        foreach (int id in ids)
        {
            if (landmarks[id].visibility < minVisibility)
            {
                hasPose = false;
                return;
            }
        }

        Vector3 leftShoulder = Convert(landmarks[11]);
        Vector3 rightShoulder = Convert(landmarks[12]);
        Vector3 leftHip = Convert(landmarks[23]);
        Vector3 rightHip = Convert(landmarks[24]);

        Vector3 shoulderCenter =
            (leftShoulder + rightShoulder) * 0.5f;

        Vector3 hipCenter =
            (leftHip + rightHip) * 0.5f;

        Vector3 up = shoulderCenter - hipCenter;
        Vector3 right = rightShoulder - leftShoulder;

        if (up.sqrMagnitude < 0.000001f ||
            right.sqrMagnitude < 0.000001f)
        {
            hasPose = false;
            return;
        }

        up.Normalize();

        // up과 직교하는 좌우 방향
        right = Vector3.ProjectOnPlane(right, up);

        if (right.sqrMagnitude < 0.000001f)
        {
            hasPose = false;
            return;
        }

        right.Normalize();

        Vector3 forward =
            Vector3.Cross(right, up).normalized;

        currentPoseRotation =
            Quaternion.LookRotation(forward, up);

        hasPose = true;
    }

    public void Calibrate()
    {
        if (!hasPose)
        {
            Debug.LogWarning(
                "추적된 상체 자세가 없어 캘리브레이션할 수 없습니다.");
            return;
        }

        referencePoseRotation = currentPoseRotation;
        calibrated = true;

        Debug.Log("상체 기준 자세 캘리브레이션 완료");
    }

    private void Update()
    {
        if (Input.GetKeyDown(KeyCode.C))
        {
            Calibrate();
        }
    }

    public void ApplyPose()
    {
        if (!initialized)
            return;

        // 기존 기준 자세 복원
        chest.localRotation = chestRestLocal;

        if (!enableRotation || !hasPose || !calibrated)
            return;

        Quaternion delta =
            currentPoseRotation *
            Quaternion.Inverse(referencePoseRotation);

        Quaternion weightedDelta =
            Quaternion.Slerp(
                Quaternion.identity,
                delta,
                rotationWeight
            );

        chest.rotation =
            weightedDelta * chest.rotation;
    }
}
