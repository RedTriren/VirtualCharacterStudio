
using UnityEngine;

public class HeadNeckRetargeter : MonoBehaviour
{
    [Header("Avatar")]
    public Animator animator;

    [Header("Coordinate Mapping")]
    public bool invertX = false;
    public bool invertY = true;
    public bool invertZ = true;

    [Header("Tracking")]
    [Range(0f, 1f)]
    public float minVisibility = 0.5f;

    [Header("Rotation")]
    [Range(0f, 1f)]
    public float neckWeight = 0.25f;

    [Range(0f, 1f)]
    public float headWeight = 0.65f;

    private Transform neck;
    private Transform head;

    private Quaternion neckRestLocal;
    private Quaternion headRestLocal;

    private Quaternion currentRotation;
    private Quaternion referenceRotation;

    private bool initialized;
    private bool hasPose;
    private bool calibrated;

    private void Start()
    {
        if (animator == null)
            animator = GetComponentInChildren<Animator>();

        if (animator == null ||
            animator.avatar == null ||
            !animator.avatar.isValid ||
            !animator.avatar.isHuman)
        {
            Debug.LogError("HeadNeck: Humanoid Avatar 오류");
            return;
        }

        neck = animator.GetBoneTransform(HumanBodyBones.Neck);
        head = animator.GetBoneTransform(HumanBodyBones.Head);

        if (head == null)
        {
            Debug.LogError("Head 뼈를 찾지 못했습니다.");
            return;
        }

        headRestLocal = head.localRotation;

        if (neck != null)
            neckRestLocal = neck.localRotation;

        initialized = true;
        Debug.Log("머리·목 리타게팅 준비 완료");
    }

    private Vector3 Convert(PoseLandmark p)
    {
        return new Vector3(
            invertX ? -p.x : p.x,
            invertY ? -p.y : p.y,
            invertZ ? -p.z : p.z
        );
    }

    public void SetPose(PoseLandmark[] landmarks)
    {
        hasPose = false;

        if (!initialized ||
            landmarks == null ||
            landmarks.Length != 33)
            return;

        // 눈 중심 2, 5는 필수
        if (landmarks[2].visibility < minVisibility ||
            landmarks[5].visibility < minVisibility)
            return;

        Vector3 left = Convert(landmarks[2]);
        Vector3 right = Convert(landmarks[5]);

        // 귀가 둘 다 유효하면 가로축을 더 넓게 구성
        if (landmarks[7].visibility >= minVisibility &&
            landmarks[8].visibility >= minVisibility)
        {
            left = Convert(landmarks[7]);
            right = Convert(landmarks[8]);
        }

        Vector3 horizontal = right - left;

        // 코와 눈 중심을 이용한 전방 방향의 근사
        Vector3 eyeCenter =
            (Convert(landmarks[2]) +
             Convert(landmarks[5])) * 0.5f;

        Vector3 nose = Convert(landmarks[0]);

        if (landmarks[0].visibility < minVisibility)
            return;

        Vector3 forwardHint = nose - eyeCenter;

        if (horizontal.sqrMagnitude < 0.000001f ||
            forwardHint.sqrMagnitude < 0.000001f)
            return;

        horizontal.Normalize();

        Vector3 forward = Vector3.ProjectOnPlane(
            forwardHint, horizontal
        );

        if (forward.sqrMagnitude < 0.000001f)
            return;

        forward.Normalize();

        // 오른쪽과 전방을 이용해 위쪽 축 구성
        Vector3 up =
            Vector3.Cross(forward, horizontal);

        if (up.sqrMagnitude < 0.000001f)
            return;

        up.Normalize();

        currentRotation =
            Quaternion.LookRotation(forward, up);

        hasPose = true;
    }

    public void Calibrate()
    {
        if (!hasPose)
        {
            Debug.LogWarning(
                "머리 캘리브레이션: 유효한 얼굴 좌표 없음");
            return;
        }

        referenceRotation = currentRotation;
        calibrated = true;

        Debug.Log("머리·목 캘리브레이션 완료");
    }

    public void ApplyPose()
    {
        if (!initialized)
            return;

        if (neck != null)
            neck.localRotation = neckRestLocal;

        head.localRotation = headRestLocal;

        if (!hasPose || !calibrated)
            return;

        Quaternion delta =
            currentRotation *
            Quaternion.Inverse(referenceRotation);

        if (neck != null)
        {
            Quaternion neckDelta = Quaternion.Slerp(
                Quaternion.identity,
                delta,
                neckWeight
            );

            neck.rotation = neckDelta * neck.rotation;
        }

        Quaternion headDelta = Quaternion.Slerp(
            Quaternion.identity,
            delta,
            headWeight
        );

        head.rotation = headDelta * head.rotation;
    }
}
