
using UnityEngine;

public class BothArmsRetargeter : MonoBehaviour
{
    [Header("Avatar")]
    public Animator animator;

    [Header("Mapping")]
    public bool swapLeftRight = false;
    public bool invertX = false;
    public bool invertY = true;
    public bool invertZ = true;

    [Header("Tracking")]
    [Range(0f, 1f)]
    public float minVisibility = 0.5f;

    private class Arm
    {
        public Transform upper;
        public Transform lower;
        public Transform hand;

        public Quaternion upperRest;
        public Quaternion lowerRest;

        public Vector3 targetUpper;
        public Vector3 targetLower;

        public bool valid;
    }

    private Arm left = new Arm();
    private Arm right = new Arm();

    private bool initialized;

    private void Start()
    {
        if (animator == null)
            animator = GetComponentInChildren<Animator>();

        if (animator == null ||
            animator.avatar == null ||
            !animator.avatar.isHuman ||
            !animator.avatar.isValid)
        {
            Debug.LogError("유효한 Humanoid Avatar가 없습니다.");
            return;
        }

        SetupArm(left,
            HumanBodyBones.LeftUpperArm,
            HumanBodyBones.LeftLowerArm,
            HumanBodyBones.LeftHand);

        SetupArm(right,
            HumanBodyBones.RightUpperArm,
            HumanBodyBones.RightLowerArm,
            HumanBodyBones.RightHand);

        initialized =
            left.upper != null && left.lower != null &&
            left.hand != null &&
            right.upper != null && right.lower != null &&
            right.hand != null;

        if (initialized)
            Debug.Log("양팔 리타게팅 준비 완료");


    }

    private void SetupArm(
        Arm arm,
        HumanBodyBones upperBone,
        HumanBodyBones lowerBone,
        HumanBodyBones handBone)
    {
        arm.upper = animator.GetBoneTransform(upperBone);
        arm.lower = animator.GetBoneTransform(lowerBone);
        arm.hand = animator.GetBoneTransform(handBone);

        if (arm.upper == null ||
            arm.lower == null ||
            arm.hand == null)
            return;

        arm.upperRest = arm.upper.localRotation;
        arm.lowerRest = arm.lower.localRotation;
    }

    private Vector3 ConvertPosition(PoseLandmark p)
    {
        return new Vector3(
            invertX ? -p.x : p.x,
            invertY ? -p.y : p.y,
            invertZ ? -p.z : p.z
        );
    }

    
    public void SetPose(PoseLandmark[] landmarks)
    {
        if (landmarks == null || landmarks.Length != 33)
        {
            left.valid = false;
            right.valid = false;
            return;
        }

        if (swapLeftRight)
        {
            SetArmTarget(left, landmarks, 12, 14, 16);
            SetArmTarget(right, landmarks, 11, 13, 15);
        }
        else
        {
            SetArmTarget(left, landmarks, 11, 13, 15);
            SetArmTarget(right, landmarks, 12, 14, 16);
        }
    }


    private void SetArmTarget(
        Arm arm,
        PoseLandmark[] landmarks,
        int shoulderId,
        int elbowId,
        int wristId)
    {
        PoseLandmark shoulder = landmarks[shoulderId];
        PoseLandmark elbow = landmarks[elbowId];
        PoseLandmark wrist = landmarks[wristId];

        if (shoulder.visibility < minVisibility ||
            elbow.visibility < minVisibility ||
            wrist.visibility < minVisibility)
        {
            arm.valid = false;
            return;
        }

        Vector3 s = ConvertPosition(shoulder);
        Vector3 e = ConvertPosition(elbow);
        Vector3 w = ConvertPosition(wrist);

        Vector3 upper = e - s;
        Vector3 lower = w - e;

        if (upper.sqrMagnitude < 0.000001f ||
            lower.sqrMagnitude < 0.000001f)
        {
            arm.valid = false;
            return;
        }

        arm.targetUpper = upper.normalized;
        arm.targetLower = lower.normalized;
        arm.valid = true;
    }

    public void ApplyPose()
    {
        if (!initialized)
            return;

        ApplyArm(left);
        ApplyArm(right);
    }

    private void ApplyArm(Arm arm)
    {
        if (!arm.valid)
            return;

        // 초기 자세 복원
        arm.upper.localRotation = arm.upperRest;
        arm.lower.localRotation = arm.lowerRest;

        // 위팔 회전
        Vector3 currentUpper =
            (arm.lower.position - arm.upper.position).normalized;

        Quaternion upperDelta =
            Quaternion.FromToRotation(
                currentUpper,
                arm.targetUpper
            );

        arm.upper.rotation =
            upperDelta * arm.upper.rotation;

        // 아래팔 회전
        Vector3 currentLower =
            (arm.hand.position - arm.lower.position).normalized;

        Quaternion lowerDelta =
            Quaternion.FromToRotation(
                currentLower,
                arm.targetLower
            );

        arm.lower.rotation =
            lowerDelta * arm.lower.rotation;
    }
}
