
using UnityEngine;

public class TorsoRetargeter : MonoBehaviour
{
    [Header("Avatar")]
    public Animator animator;

    [Header("Coordinate Mapping")]
    public bool invertX = false;
    public bool invertY = true;
    public bool invertZ = true;

    [Header("Rotation Weights")]
    [Range(0f, 1f)]
    public float hipsWeight = 0.5f;

    [Range(0f, 1f)]
    public float spineWeight = 0.35f;

    [Range(0f, 1f)]
    public float chestWeight = 0.35f;

    [Header("Tracking")]
    [Range(0f, 1f)]
    public float minVisibility = 0.5f;

    private Transform hips;
    private Transform spine;
    private Transform chest;

    private Quaternion hipsRestLocal;
    private Quaternion spineRestLocal;
    private Quaternion chestRestLocal;

    private Quaternion currentHipRotation;
    private Quaternion currentShoulderRotation;

    private Quaternion referenceHipRotation;
    private Quaternion referenceShoulderRotation;

    private bool initialized;
    private bool hasPose;
    private bool calibrated;

    private void Start()
    {
        if (animator == null)
            animator = GetComponentInChildren<Animator>();

        if (animator == null ||
            animator.avatar == null ||
            !animator.avatar.isValid ||
            !animator.avatar.isHuman)
        {
            Debug.LogError("Humanoid Animator 오류");
            return;
        }

        hips = animator.GetBoneTransform(
            HumanBodyBones.Hips);

        spine = animator.GetBoneTransform(
            HumanBodyBones.Spine);

        chest = animator.GetBoneTransform(
            HumanBodyBones.Chest);

        if (hips == null || spine == null)
        {
            Debug.LogError("Hips 또는 Spine 뼈를 찾지 못했습니다.");
            return;
        }

        hipsRestLocal = hips.localRotation;
        spineRestLocal = spine.localRotation;

        if (chest != null)
            chestRestLocal = chest.localRotation;

        initialized = true;

        Debug.Log("TorsoRetargeter 준비 완료");
    }

    private Vector3 Convert(PoseLandmark p)
    {
        return new Vector3(
            invertX ? -p.x : p.x,
            invertY ? -p.y : p.y,
            invertZ ? -p.z : p.z
        );
    }

    private Quaternion BuildRotation(
        Vector3 right,
        Vector3 up)
    {
        up.Normalize();

        right = Vector3.ProjectOnPlane(
            right, up
        ).normalized;

        Vector3 forward =
            Vector3.Cross(right, up).normalized;

        return Quaternion.LookRotation(
            forward, up
        );
    }

    public void SetPose(PoseLandmark[] landmarks)
    {
        if (!initialized ||
            landmarks == null ||
            landmarks.Length != 33)
        {
            hasPose = false;
            return;
        }

        int[] ids = { 11, 12, 23, 24 };

        foreach (int id in ids)
        {
            if (landmarks[id].visibility < minVisibility)
            {
                hasPose = false;
                return;
            }
        }

        Vector3 ls = Convert(landmarks[11]);
        Vector3 rs = Convert(landmarks[12]);
        Vector3 lh = Convert(landmarks[23]);
        Vector3 rh = Convert(landmarks[24]);

        Vector3 shoulderCenter = (ls + rs) * 0.5f;
        Vector3 hipCenter = (lh + rh) * 0.5f;

        Vector3 torsoUp = shoulderCenter - hipCenter;

        Vector3 hipRight = rh - lh;
        Vector3 shoulderRight = rs - ls;

        if (torsoUp.sqrMagnitude < 0.000001f ||
            hipRight.sqrMagnitude < 0.000001f ||
            shoulderRight.sqrMagnitude < 0.000001f)
        {
            hasPose = false;
            return;
        }

        currentHipRotation =
            BuildRotation(hipRight, torsoUp);

        currentShoulderRotation =
            BuildRotation(shoulderRight, torsoUp);

        hasPose = true;
    }

    public void Calibrate()
    {
        if (!hasPose)
        {
            Debug.LogWarning(
                "캘리브레이션할 상체 데이터가 없습니다.");
            return;
        }

        referenceHipRotation = currentHipRotation;
        referenceShoulderRotation =
            currentShoulderRotation;

        calibrated = true;

        Debug.Log("골반·상체 캘리브레이션 완료");
    }

    private void Update()
    {
        if (Input.GetKeyDown(KeyCode.C))
        {
            Calibrate();
        }
    }

    public void ApplyPose()
    {
        if (!initialized)
            return;

        hips.localRotation = hipsRestLocal;
        spine.localRotation = spineRestLocal;

        if (chest != null)
            chest.localRotation = chestRestLocal;

        if (!hasPose || !calibrated)
            return;

        // 1. 골반 회전 변화
        Quaternion hipDelta =
            currentHipRotation *
            Quaternion.Inverse(referenceHipRotation);

        // 2. 어깨 회전 변화
        Quaternion shoulderDelta =
            currentShoulderRotation *
            Quaternion.Inverse(referenceShoulderRotation);

        // 3. 골반에 대한 상체의 상대 회전
        Quaternion relativeDelta =
            Quaternion.Inverse(hipDelta) *
            shoulderDelta;

        // 4. 골반 회전
        Quaternion weightedHip =
            Quaternion.Slerp(
                Quaternion.identity,
                hipDelta,
                hipsWeight
            );

        hips.rotation =
            weightedHip * hips.rotation;

        // 5. 척추 회전
        Quaternion weightedSpine =
            Quaternion.Slerp(
                Quaternion.identity,
                relativeDelta,
                spineWeight
            );

        spine.rotation =
            weightedSpine * spine.rotation;

        // 6. 가슴 회전
        if (chest != null)
        {
            Quaternion weightedChest =
                Quaternion.Slerp(
                    Quaternion.identity,
                    relativeDelta,
                    chestWeight
                );

            chest.rotation =
                weightedChest * chest.rotation;
        }
    }
}
